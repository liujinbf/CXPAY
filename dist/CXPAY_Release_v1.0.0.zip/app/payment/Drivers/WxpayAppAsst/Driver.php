<?php

declare(strict_types=1);

namespace app\payment\Drivers\WxpayAppAsst;

use app\payment\AbstractPersonalQrDriver;

/**
 * 微信 App 挂机助手驱动插件
 */
class Driver extends AbstractPersonalQrDriver
{
    protected function cType(): string
    {
        return 'wxpay_app_asst';
    }

    protected function title(): string
    {
        return '微信个人收款码 / 赞赏码（安卓手机 App 挂机监控）';
    }

    protected function description(): string
    {
        return '展示微信个人收款码/赞赏码，由商户备用安卓手机安装 CXPayAssistant 助手监听微信到账并安全上报';
    }

    protected function qrField(): string
    {
        return 'qr_code_url';
    }

    protected function qrTitle(): string
    {
        return '微信个人收款码/赞赏码内容';
    }

    protected function platform(): string
    {
        return 'wxpay';
    }

    public function getMeta(): array
    {
        $meta = parent::getMeta();
        $meta['inputs'] = [
            [
                'type' => 'notice',
                'title' => '📱 微信安卓手机挂机助手配置指南',
                'content' => "💡 原理说明：\n"
                    . "• 备用安卓手机安装 CXPayAssistant 挂机助手 App，并登录收款微信号。\n"
                    . "• 助手利用系统无障碍与通知监听，在手机收到微信到账提示时瞬间抓取金额与单号并安全上报。\n\n"
                    . "📌 快速配置步骤：\n"
                    . "1. 【准备收款码】保存微信的「赞赏码」或「个人收款码」，点击下方「📷 上传收款码图片」自动识别解析填入。\n"
                    . "2. 【安装助手 App】在安卓手机安装 CXPayAssistant，开启「无障碍服务」与「通知读取权限」，并关闭电池优化。\n"
                    . "3. 【扫码连接】在 App 中扫描下方的一键配置二维码（或手动填入设备ID与密钥），点击【启动监听】即可。",
                'tone' => 'info',
            ],
            [
                'name' => 'qr_code_url',
                'title' => '微信个人收款码内容（必填）',
                'type' => 'string',
                'required' => true,
            ],
            [
                'name' => 'device_id',
                'title' => '监控设备 ID',
                'type' => 'string',
                'required' => true,
            ],
            [
                'name' => 'notify_secret',
                'title' => '监控端 HMAC 推送密钥',
                'type' => 'password',
                'required' => true,
            ],
        ];
        return $meta;
    }

    public function upchannel(array $channel, array $config): array
    {
        if (empty($config['qr_code_url'])) {
            return ['code' => -1, 'msg' => '请上传或填入微信收款码/赞赏码内容'];
        }
        if (empty($config['device_id'])) {
            $config['device_id'] = 'WX_APP_' . bin2hex(random_bytes(4));
        }
        if (empty($config['notify_secret']) || strlen((string)$config['notify_secret']) < 16) {
            $config['notify_secret'] = bin2hex(random_bytes(16));
        }

        return ['code' => 1, 'msg' => 'ok', 'data' => $config];
    }
}

