<?php

declare(strict_types=1);

namespace app\payment\Drivers\WechatWecomApp;

use app\payment\Contracts\MonitorableDriverInterface;
use app\payment\Contracts\PaymentDriverInterface;
use Illuminate\Database\Capsule\Manager as DB;

/**
 * 微信官方企业微信自建应用 Webhook 免挂插件
 *
 * 支持平台统一企业微信托管（商户零门槛扫码加店员）与商户独立企业微信自建应用直连。
 */
class Driver implements PaymentDriverInterface, MonitorableDriverInterface
{
    public function monitorMode(): string
    {
        return MonitorableDriverInterface::MODE_CALLBACK;
    }

    public function pay(array $params, array $config): array
    {
        $qr = trim((string)($config['qr_code_url'] ?? ''));

        return [
            'type'         => 'qrcode',
            'trade_no'     => (string)($params['trade_no'] ?? ''),
            'out_trade_no' => (string)($params['out_trade_no'] ?? ''),
            'amount'       => $params['money'] ?? '0.00',
            'pay_url'      => $qr,
        ];
    }

    public function notify(array $params, array $config): array
    {
        return [
            'success'      => false,
            'out_trade_no' => '',
            'trade_no'     => '',
            'amount'       => 0.0,
        ];
    }

    public function query(string $tradeNo, array $config): array
    {
        return ['paid' => false];
    }

    public function upchannel(array $channel, array $config): array
    {
        if (empty($config['qr_code_url'])) {
            return ['code' => -1, 'msg' => '请上传或填入微信收款码内容'];
        }

        // 读取平台统一企业微信全局配置
        $platformConfigs = [];
        try {
            $platformConfigs = DB::table('cx_config')
                ->whereIn('name', [
                    'platform_wecom_enabled',
                    'platform_wecom_token',
                    'platform_wecom_encoding_aes_key',
                    'platform_wecom_corp_id',
                ])
                ->pluck('value', 'name');
        } catch (\Throwable) {}

        $isPlatformHosted = ($platformConfigs['platform_wecom_enabled'] ?? '1') === '1'
            && !empty($platformConfigs['platform_wecom_token']);

        // 若商户未填 Token / AESKey，自动继承平台统一托管参数
        if (empty($config['token'])) {
            $config['token'] = $isPlatformHosted
                ? (string)$platformConfigs['platform_wecom_token']
                : bin2hex(random_bytes(8));
        }
        if (empty($config['encoding_aes_key'])) {
            $config['encoding_aes_key'] = $isPlatformHosted
                ? (string)$platformConfigs['platform_wecom_encoding_aes_key']
                : substr(base64_encode(random_bytes(32)), 0, 43);
        }
        if (empty($config['corp_id']) && $isPlatformHosted) {
            $config['corp_id'] = (string)($platformConfigs['platform_wecom_corp_id'] ?? '');
        }

        return ['code' => 1, 'msg' => 'ok', 'data' => $config];
    }

    public function getMeta(): array
    {
        $platformConfigs = [];
        try {
            $platformConfigs = DB::table('cx_config')
                ->whereIn('name', [
                    'platform_wecom_enabled',
                    'platform_wecom_clerk_qrcode',
                    'platform_wecom_clerk_name',
                    'platform_wecom_token',
                ])
                ->pluck('value', 'name');
        } catch (\Throwable) {}

        $isPlatformHosted = ($platformConfigs['platform_wecom_enabled'] ?? '1') === '1'
            && !empty($platformConfigs['platform_wecom_token']);
        $clerkQrcode = (string)($platformConfigs['platform_wecom_clerk_qrcode'] ?? '');
        $clerkName = (string)($platformConfigs['platform_wecom_clerk_name'] ?? '平台收款店员');

        $noticeContent = $isPlatformHosted
            ? "🌟 【平台统一免挂模式已启用】：商户无需注册企业微信或申请营业执照！\n"
              . "• 资金 100% 直入老板个人微信零钱或银行卡。\n"
              . "• 步骤 1：上传您的微信收款码。\n"
              . "• 步骤 2：在手机微信打开「微信收款小账本」->「店员管理」->「添加店员」，扫码添加【{$clerkName}】为店员（仅需1次，永久免挂）！"
            : "💡 原理说明：\n"
              . "• 资金 100% 直入老板微信零钱或银行卡。\n"
              . "• 微信收款小账本通知将自动同步至企业微信自建应用中。\n"
              . "• 企业微信通过官方 HTTP Webhook 将到账消息实时推送至本系统完成全自动核销，无需实体手机或电脑挂机！";

        return [
            'name'                   => 'wechat_wecom_app',
            'title'                  => '企业微信自建应用（云端免挂 Webhook 插件）',
            'description'            => '基于企业微信自建应用 Webhook 官方开放平台直连，云端接收微信收款通知，免手机/电脑挂机，零封号风险。',
            'pay_category'           => 'wxpay',
            'collection_mode'        => 'personal_qr',
            'monitor_mode'           => $this->monitorMode(),
            'platform_hosted'        => $isPlatformHosted,
            'platform_clerk_qrcode'  => $clerkQrcode,
            'platform_clerk_name'    => $clerkName,
            'inputs'                 => [
                [
                    'type'    => 'notice',
                    'title'   => $isPlatformHosted ? '✨ 微信官方免挂 · 平台统一托管模式' : '📖 企业微信自建应用 Webhook 配置说明',
                    'content' => $noticeContent,
                    'tone'    => 'info',
                ],
                [
                    'name'     => 'qr_code_url',
                    'title'    => '微信收款码内容',
                    'type'     => 'string',
                    'required' => true,
                ],
                [
                    'name'     => 'token',
                    'title'    => '回调校验 Token（平台托管模式已自动填入）',
                    'type'     => 'string',
                    'required' => false,
                ],
                [
                    'name'     => 'encoding_aes_key',
                    'title'    => '消息加解密密钥 EncodingAESKey（平台托管模式已自动填入）',
                    'type'     => 'password',
                    'required' => false,
                ],
                [
                    'name'     => 'corp_id',
                    'title'    => '企业微信 CorpID（选填）',
                    'type'     => 'string',
                    'required' => false,
                ],
                [
                    'name'     => 'agent_id',
                    'title'    => '自建应用 AgentId（选填）',
                    'type'     => 'string',
                    'required' => false,
                ],
            ],
        ];
    }
}
