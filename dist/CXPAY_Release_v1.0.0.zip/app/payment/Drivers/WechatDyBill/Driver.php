<?php

declare(strict_types=1);

namespace app\payment\Drivers\WechatDyBill;

use app\payment\AbstractPersonalQrDriver;

/**
 * 微信店员小账本免挂监控驱动插件
 */
class Driver extends AbstractPersonalQrDriver
{
    protected function cType(): string
    {
        return 'wechat_dy_bill';
    }

    protected function title(): string
    {
        return '微信店员小账本免挂监控（免手机挂机 / 官方店员协议）';
    }

    protected function description(): string
    {
        return '商户微信小账本添加店员，资金 100% 进商户零钱，由店员手机/挂机端接收微信官方到账通知并自动核销';
    }

    protected function qrField(): string
    {
        return 'qr_code_url';
    }

    protected function qrTitle(): string
    {
        return '微信小账本收款码/赞赏码内容';
    }

    protected function platform(): string
    {
        return 'wxpay';
    }

    public function getMeta(): array
    {
        $meta = parent::getMeta();
        $meta['platform_hosted'] = true;
        
        $platformClerkQrcode = '';
        $platformClerkName = '平台官方收款店员';
        
        try {
            $file = runtime_path() . '/wechat_dy_bill_clerk.json';
            if (file_exists($file)) {
                $data = json_decode((string)file_get_contents($file), true) ?: [];
                $platformClerkQrcode = (string)($data['clerk_qrcode'] ?? '');
                $platformClerkName = (string)($data['clerk_name'] ?? '平台官方收款店员');
            }

            if (empty($platformClerkQrcode)) {
                $channel = \app\model\Channel::where('merchant_id', 0)->where('c_type', 'wechat_dy_bill')->first();
                if ($channel && !empty($channel->config)) {
                    $rawConfig = json_decode((string)$channel->config, true) ?: [];
                    $platformClerkQrcode = (string)($rawConfig['clerk_qrcode'] ?? '');
                    $platformClerkName = (string)($rawConfig['clerk_name'] ?? '平台官方收款店员');
                }
            }
        } catch (\Throwable) {
            // ignore
        }

        if (empty($platformClerkName)) {
            $platformClerkName = '平台官方收款店员';
        }

        $meta['platform_clerk_qrcode'] = $platformClerkQrcode;
        $meta['platform_clerk_name'] = $platformClerkName;

        $meta['inputs'] = [
            [
                'type' => 'notice',
                'title' => '📖 微信店员小账本（平台统一托管免挂）',
                'content' => "💡 原理说明：\n"
                    . "• 资金收款：客户扫码付款后，资金 100% 直入【商户微信零钱/银行卡】（商户无需挂机，资金 0 风险）。\n"
                    . "• 统一托管：平台统一托管店员号，微信官方推送收款通知，秒级自动核销订单！\n\n"
                    . "📌 极速接入步骤：\n"
                    . "1. 【添加店员】商户打开微信小程序「微信收款小账本」->「店员管理」->「添加店员」，扫描上方【平台官方店员二维码】发送邀请（仅需 1 次，永久免挂）。\n"
                    . "2. 【上传收款码】保存商户微信的「赞赏码」或「收款小账本物料码」，点击下方「📷 上传收款码图片」自动识别填入即可！",
                'tone' => 'info',
            ],
            [
                'name' => 'qr_code_url',
                'title' => '微信小账本收款码/赞赏码内容（必填）',
                'type' => 'string',
                'required' => true,
                'placeholder' => '点击右侧「📷 上传收款码图片自动识别」，或手动填入 wxp:// 链接',
            ],
            [
                'name' => 'clerk_qrcode',
                'title' => '平台官方店员二维码（已由主站统一托管）',
                'type' => 'string',
                'required' => false,
                'default' => $platformClerkQrcode,
            ],
            [
                'name' => 'clerk_name',
                'title' => '平台官方店员昵称',
                'type' => 'string',
                'required' => false,
                'default' => $platformClerkName,
            ],
            [
                'name' => 'device_id',
                'title' => '店员监控设备 ID',
                'type' => 'string',
                'required' => false,
            ],
            [
                'name' => 'notify_secret',
                'title' => '监控端 HMAC 推送密钥',
                'type' => 'password',
                'required' => false,
            ],
        ];
        return $meta;
    }

    public function upchannel(array $channel, array $config): array
    {
        if (empty($config['qr_code_url'])) {
            return ['code' => -1, 'msg' => '请上传或填入微信小账本收款码/赞赏码内容'];
        }
        if (empty($config['device_id'])) {
            $config['device_id'] = 'WX_CLERK_' . bin2hex(random_bytes(4));
        }
        if (empty($config['notify_secret']) || strlen((string)$config['notify_secret']) < 16) {
            $config['notify_secret'] = bin2hex(random_bytes(16));
        }

        return ['code' => 1, 'msg' => 'ok', 'data' => $config];
    }
}

