<?php

declare(strict_types=1);

namespace app\payment\Drivers\WxpayRecptAfkPc;

use app\payment\AbstractPersonalQrDriver;

/**
 * 微信收款码 PC 挂机账单捕获驱动插件
 */
class Driver extends AbstractPersonalQrDriver
{
    protected function cType(): string
    {
        return 'wxpay_recpt_afk_pc';
    }

    protected function title(): string
    {
        return '微信小账本（PC 桌面/云端挂机）';
    }

    protected function description(): string
    {
        return '展示微信个人收款码/赞赏码，由 Windows 服务器或桌面运行 PC 微信自动捕获到账记录并安全上报';
    }

    protected function qrField(): string
    {
        return 'qr_code_url';
    }

    protected function qrTitle(): string
    {
        return '微信个人收款码/赞赏码内容';
    }

    protected function platform(): string
    {
        return 'wxpay';
    }

    public function getMeta(): array
    {
        $meta = parent::getMeta();
        $meta['inputs'] = [
            [
                'type' => 'notice',
                'title' => '🖥️ 微信 PC 挂机监控（小账本/赞赏码）配置指南',
                'content' => "💡 原理说明：\n"
                    . "• 运行在 Windows 服务器/挂机宝上的官方 PC 微信，登录店员微信号并打开「微信收款小账本」小程序。\n"
                    . "• 配合 CXPayMonitor PC 监控软件，直接在官方客户端内毫秒级捕获微信到账并安全推送给系统，免手机免充电。\n\n"
                    . "📌 快速配置步骤：\n"
                    . "1. 【准备收款码】保存商户微信的「赞赏码」或「微信收款小账本物料码」，点击下方「📷 上传收款码图片」自动识别解析。\n"
                    . "2. 【配置 PC 监控端】在 Windows 电脑运行 CXPayMonitor，填入主站网关地址、设备 ID 和 通信密钥。\n"
                    . "3. 【启动挂机】在电脑上登录店员 PC 微信，点击监控端【开始监控】即可实现 24 小时全自动回调。",
                'tone' => 'info',
            ],
            [
                'name' => 'qr_code_url',
                'title' => '微信收款码/赞赏码内容（必填）',
                'type' => 'string',
                'required' => true,
            ],
            [
                'name' => 'device_id',
                'title' => 'PC 客户端设备 ID',
                'type' => 'string',
                'required' => true,
            ],
            [
                'name' => 'notify_secret',
                'title' => 'PC 客户端通信 Token / 签名密钥',
                'type' => 'password',
                'required' => true,
            ],
        ];
        return $meta;
    }

    public function upchannel(array $channel, array $config): array
    {
        if (empty($config['qr_code_url'])) {
            return ['code' => -1, 'msg' => '请上传或填入微信收款码/赞赏码内容'];
        }
        if (empty($config['device_id'])) {
            $config['device_id'] = 'WX_PC_' . bin2hex(random_bytes(4));
        }
        if (empty($config['notify_secret']) || strlen((string)$config['notify_secret']) < 16) {
            $config['notify_secret'] = bin2hex(random_bytes(16));
        }

        return ['code' => 1, 'msg' => 'ok', 'data' => $config];
    }
}

