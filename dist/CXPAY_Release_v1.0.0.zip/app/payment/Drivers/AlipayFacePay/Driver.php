<?php

declare(strict_types=1);

namespace app\payment\Drivers\AlipayFacePay;

use app\payment\Contracts\PaymentDriverInterface;
use support\Db;

/**
 * 支付宝当面付 / 官方直连商户驱动插件
 *
 * 支持双模式运行：
 * 1. 模式一：商户自主填写 AppID + RSA2 私钥直连模式；
 * 2. 模式二：官方 ISV 第三方应用 AppAuth 扫码一键代授权模式（app_auth_token）。
 */
class Driver implements PaymentDriverInterface
{
    public function pay(array $params, array $config): array
    {
        $appAuthToken = trim((string)($config['app_auth_token'] ?? ''));
        $appId = trim((string)($config['app_id'] ?? ''));
        $privateKey = trim((string)($config['merchant_private_key'] ?? ''));
        $qrCodeFallback = trim((string)($config['qr_code_url'] ?? ''));

        // 如果是 AppAuth 扫码授权模式，若商户未配置独立私钥则自动使用平台 ISV 统一私钥签名
        if ($appAuthToken !== '' && ($appId === '' || $privateKey === '')) {
            $isvConfig = $this->getIsvConfig();
            $appId = $isvConfig['app_id'] ?: $appId;
            $privateKey = $isvConfig['private_key'] ?: $privateKey;
        }

        // 发起官方 alipay.trade.precreate 预下单获取真实动态收款码
        if ($appId !== '' && $privateKey !== '') {
            $tradeNo = (string)($params['trade_no'] ?? ('CX' . date('YmdHis') . mt_rand(1000, 9999)));
            $money = number_format((float)($params['money'] ?? 0.01), 2, '.', '');
            $subject = (string)($params['name'] ?? '支付测试');

            $bizContent = [
                'out_trade_no'    => $tradeNo,
                'total_amount'    => $money,
                'subject'         => $subject,
                'timeout_express' => '10m',
            ];

            $sysParams = [
                'app_id'      => $appId,
                'method'      => 'alipay.trade.precreate',
                'format'      => 'JSON',
                'charset'     => 'utf-8',
                'sign_type'   => 'RSA2',
                'timestamp'   => date('Y-m-d H:i:s'),
                'version'     => '1.0',
                'biz_content' => json_encode($bizContent, JSON_UNESCAPED_UNICODE),
            ];

            // ISV 模式下附带商户应用授权令牌
            if ($appAuthToken !== '') {
                $sysParams['app_auth_token'] = $appAuthToken;
            }

            if (!empty($params['notify_url'])) {
                $sysParams['notify_url'] = $params['notify_url'];
            }

            $sign = $this->rsaSign($sysParams, $privateKey);
            $sysParams['sign'] = $sign;

            // 发起请求到支付宝网关（必须在 URL query string 中带上 charset=utf-8）
            $response = $this->postHttp('https://openapi.alipay.com/gateway.do?charset=utf-8', $sysParams);
            if (!mb_check_encoding($response, 'UTF-8')) {
                $response = mb_convert_encoding($response, 'UTF-8', 'GBK,GB2312,BIG5');
            }
            $result = json_decode($response, true);
            $respData = $result['alipay_trade_precreate_response'] ?? $result['error_response'] ?? null;

            if (is_array($respData)) {
                if (($respData['code'] ?? '') === '10000' && !empty($respData['qr_code'])) {
                    return [
                        'type'         => 'qrcode',
                        'trade_no'     => $tradeNo,
                        'out_trade_no' => (string)($params['out_trade_no'] ?? ''),
                        'amount'       => $money,
                        'pay_url'      => $respData['qr_code'],
                    ];
                }
                $subCode = (string)($respData['sub_code'] ?? '');
                $subMsg = (string)($respData['sub_msg'] ?? $respData['msg'] ?? '支付宝下单失败');
                if (str_contains($subCode, 'invalid-signature')) {
                    $subMsg = '应用公私钥不匹配：您填写的「应用私钥」与支付宝开放平台后台保存的「应用公钥」不是同一对。请在本地密钥工具中点击「生成密钥」，将新私钥填入此处，并将新公钥在支付宝后台点击「变更」上传保存。';
                } elseif (str_contains($subCode, 'insufficient-isv-permissions') || str_contains($subCode, 'isv.insufficient')) {
                    $subMsg = '应用尚未开通「当面付」能力：请登录支付宝开放平台(open.alipay.com)进入该应用详情，在「能力列表」中添加「当面付」并确认签约开通即可。';
                } elseif (str_contains($subCode, 'invalid-app-auth-token') || str_contains($subCode, 'app-auth-token-expired')) {
                    $subMsg = '商户授权令牌已过期或失效，请在商户后台重新进行「支付宝一键扫码授权绑定」。';
                }
                throw new \RuntimeException($subMsg);
            }
        }

        if ($qrCodeFallback !== '') {
            return [
                'type'         => 'qrcode',
                'trade_no'     => (string)($params['trade_no'] ?? ''),
                'out_trade_no' => (string)($params['out_trade_no'] ?? ''),
                'amount'       => $params['money'] ?? '0.00',
                'pay_url'      => $qrCodeFallback,
            ];
        }

        throw new \RuntimeException('未配置有效的支付宝 AppID 或授权令牌');
    }

    public function notify(array $params, array $config): array
    {
        $status = (string)($params['trade_status'] ?? '');
        if ($status !== 'TRADE_SUCCESS' && $status !== 'TRADE_FINISHED') {
            return ['success' => false, 'msg' => '非支付成功状态: ' . $status];
        }

        // 验证支付宝公钥签名
        $publicKey = trim((string)($config['alipay_public_key'] ?? ''));
        if ($publicKey === '') {
            $isvConfig = $this->getIsvConfig();
            $publicKey = $isvConfig['public_key'] ?: '';
        }

        if ($publicKey !== '' && !empty($params['sign'])) {
            $sign = (string)$params['sign'];
            $signType = strtoupper((string)($params['sign_type'] ?? 'RSA2'));
            if ($signType === 'RSA2' && !$this->rsaVerify($params, $sign, $publicKey)) {
                return ['success' => false, 'msg' => '支付宝公钥验签失败'];
            }
        }

        return [
            'success'      => true,
            'out_trade_no' => (string)($params['out_trade_no'] ?? ''),
            'trade_no'     => (string)($params['trade_no'] ?? ''),
            'amount'       => (float)($params['total_amount'] ?? $params['buyer_pay_amount'] ?? 0),
        ];
    }

    public function query(string $tradeNo, array $config): array
    {
        $appAuthToken = trim((string)($config['app_auth_token'] ?? ''));
        $appId = trim((string)($config['app_id'] ?? ''));
        $privateKey = trim((string)($config['merchant_private_key'] ?? ''));

        if ($appAuthToken !== '' && ($appId === '' || $privateKey === '')) {
            $isvConfig = $this->getIsvConfig();
            $appId = $isvConfig['app_id'] ?: $appId;
            $privateKey = $isvConfig['private_key'] ?: $privateKey;
        }

        if ($appId === '' || $privateKey === '') {
            return ['paid' => false];
        }

        $bizContent = ['out_trade_no' => $tradeNo];
        $sysParams = [
            'app_id'      => $appId,
            'method'      => 'alipay.trade.query',
            'format'      => 'JSON',
            'charset'     => 'utf-8',
            'sign_type'   => 'RSA2',
            'timestamp'   => date('Y-m-d H:i:s'),
            'version'     => '1.0',
            'biz_content' => json_encode($bizContent, JSON_UNESCAPED_UNICODE),
        ];

        if ($appAuthToken !== '') {
            $sysParams['app_auth_token'] = $appAuthToken;
        }

        $sign = $this->rsaSign($sysParams, $privateKey);
        $sysParams['sign'] = $sign;

        try {
            $response = $this->postHttp('https://openapi.alipay.com/gateway.do?charset=utf-8', $sysParams);
            if (!mb_check_encoding($response, 'UTF-8')) {
                $response = mb_convert_encoding($response, 'UTF-8', 'GBK,GB2312,BIG5');
            }
            $result = json_decode($response, true);
            $respData = $result['alipay_trade_query_response'] ?? null;
            if (is_array($respData) && ($respData['code'] ?? '') === '10000') {
                $status = (string)($respData['trade_status'] ?? '');
                if ($status === 'TRADE_SUCCESS' || $status === 'TRADE_FINISHED') {
                    return [
                        'paid'         => true,
                        'trade_no'     => (string)($respData['trade_no'] ?? ''),
                        'out_trade_no' => (string)($respData['out_trade_no'] ?? $tradeNo),
                        'amount'       => (float)($respData['total_amount'] ?? 0),
                    ];
                }
            }
        } catch (\Throwable) {
            // 忽略网络异常
        }

        return ['paid' => false];
    }

    private function getIsvConfig(): array
    {
        try {
            $dbConfigs = Db::table('cx_config')->whereIn('name', [
                'alipay_isv_app_id',
                'alipay_isv_private_key',
                'alipay_isv_public_key',
                'alipay_app_id',
                'alipay_private_key',
            ])->pluck('value', 'name')->toArray();

            $appId = $dbConfigs['alipay_isv_app_id'] ?? $dbConfigs['alipay_app_id'] ?? env('ALIPAY_ISV_APP_ID', env('ALIPAY_APP_ID', ''));
            $privateKey = $dbConfigs['alipay_isv_private_key'] ?? $dbConfigs['alipay_private_key'] ?? env('ALIPAY_ISV_PRIVATE_KEY', env('ALIPAY_PRIVATE_KEY', ''));
            $publicKey = $dbConfigs['alipay_isv_public_key'] ?? env('ALIPAY_ISV_PUBLIC_KEY', env('ALIPAY_PUBLIC_KEY', ''));

            return [
                'app_id'      => (string)$appId,
                'private_key' => (string)$privateKey,
                'public_key'  => (string)$publicKey,
            ];
        } catch (\Throwable) {
            return [
                'app_id'      => (string)env('ALIPAY_ISV_APP_ID', env('ALIPAY_APP_ID', '')),
                'private_key' => (string)env('ALIPAY_ISV_PRIVATE_KEY', env('ALIPAY_PRIVATE_KEY', '')),
                'public_key'  => (string)env('ALIPAY_ISV_PUBLIC_KEY', env('ALIPAY_PUBLIC_KEY', '')),
            ];
        }
    }

    private function rsaSign(array $params, string $privateKey): string
    {
        ksort($params);
        $signStr = '';
        foreach ($params as $k => $v) {
            if ($k !== 'sign' && $v !== '' && $v !== null) {
                $signStr .= $k . '=' . $v . '&';
            }
        }
        $signStr = rtrim($signStr, '&');

        $formattedKey = $this->formatPrivateKey($privateKey);
        $res = openssl_get_privatekey($formattedKey);
        if (!$res) {
            throw new \RuntimeException('应用私钥格式不正确，无法解析为有效 RSA2 私钥');
        }

        openssl_sign($signStr, $signature, $res, OPENSSL_ALGO_SHA256);
        return base64_encode($signature);
    }

    private function rsaVerify(array $params, string $sign, string $publicKey): bool
    {
        $signStr = '';
        ksort($params);
        foreach ($params as $k => $v) {
            if ($k !== 'sign' && $k !== 'sign_type' && $v !== '' && !is_null($v)) {
                $signStr .= "{$k}={$v}&";
            }
        }
        $signStr = rtrim($signStr, '&');

        $formattedPub = $this->formatPublicKey($publicKey);
        $res = openssl_pkey_get_public($formattedPub);
        if (!$res) {
            return false;
        }

        return openssl_verify($signStr, base64_decode($sign), $res, OPENSSL_ALGO_SHA256) === 1;
    }

    private function formatPrivateKey(string $key): string
    {
        $key = trim($key);
        if (str_starts_with($key, '-----BEGIN')) {
            return $key;
        }
        $pkcs8 = "-----BEGIN PRIVATE KEY-----\n" . wordwrap($key, 64, "\n", true) . "\n-----END PRIVATE KEY-----";
        if (openssl_get_privatekey($pkcs8)) {
            return $pkcs8;
        }
        return "-----BEGIN RSA PRIVATE KEY-----\n" . wordwrap($key, 64, "\n", true) . "\n-----END RSA PRIVATE KEY-----";
    }

    private function formatPublicKey(string $key): string
    {
        $key = trim($key);
        if (str_starts_with($key, '-----BEGIN')) {
            return $key;
        }
        return "-----BEGIN PUBLIC KEY-----\n" . wordwrap($key, 64, "\n", true) . "\n-----END PUBLIC KEY-----";
    }

    private function postHttp(string $url, array $params): string
    {
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($params));
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
        curl_setopt($ch, CURLOPT_TIMEOUT, 10);
        $output = curl_exec($ch);
        if (curl_errno($ch)) {
            $err = curl_error($ch);
            curl_close($ch);
            throw new \RuntimeException('请求支付宝网关网络异常: ' . $err);
        }
        curl_close($ch);
        return (string)$output;
    }

    public function getMeta(): array
    {
        return [
            'name'            => 'alipay_face_pay',
            'title'           => '支付宝当面付 / 官方直连商户插件',
            'description'     => '支持手机支付宝扫码一键代授权（0配置）或自主填入 AppID 与 RSA2 密钥直连，资金秒级直达商户账户，0 掉单',
            'pay_category'    => 'alipay',
            'collection_mode' => 'gateway',
            'has_oauth'       => true,
            'oauth_btn_title' => '📱 支付宝扫码一键绑定当面付',
            'inputs'          => [
                [
                    'type'    => 'notice',
                    'title'   => '💡 支付宝当面付提供两种极速接入方式：',
                    'content' => "【方式 1：📱 扫码一键授权 (推荐)】：点击上方「📱 支付宝扫码一键绑定当面付」按钮，使用开通了当面付的手机支付宝扫码点同意，系统全自动完成应用授权与通道配置，0 填写、0 门槛！\n\n【方式 2：自主填写密钥】：若您希望使用自己独立的开放平台应用，可进入【支付宝开放平台 (open.alipay.com)】创建应用，生成 RSA2 密钥并在下方依次填入 AppID、应用私钥和支付宝公钥。",
                    'links'   => [
                        [
                            'title' => '🔗 直达支付宝开放平台控制台',
                            'url'   => 'https://open.alipay.com/platform/home.htm',
                        ],
                        [
                            'title' => '📥 官方开发助手 (密钥工具) 下载',
                            'url'   => 'https://opendocs.alipay.com/common/02kipl',
                        ],
                    ],
                ],
                [
                    'name'        => 'app_id',
                    'title'       => '支付宝应用 AppID (自主填写模式选填)',
                    'placeholder' => '如使用扫码一键授权可留空；自主配置请填入例如: 2021001234567890',
                    'type'        => 'string',
                    'required'    => false,
                ],
                [
                    'name'        => 'merchant_private_key',
                    'title'       => '应用私钥 (自主填写模式选填)',
                    'placeholder' => '如使用扫码一键授权可留空；自主配置请粘贴生成的商户应用私钥',
                    'type'        => 'textarea',
                    'required'    => false,
                ],
                [
                    'name'        => 'alipay_public_key',
                    'title'       => '支付宝公钥 (可选)',
                    'placeholder' => '开放平台后台保存加签方式后生成的「支付宝公钥」',
                    'type'        => 'textarea',
                    'required'    => false,
                ],
            ],
        ];
    }

    public function upchannel(array $channelRow, array $config): array
    {
        $appAuthToken = trim((string)($config['app_auth_token'] ?? ''));
        $appId = trim((string)($config['app_id'] ?? ''));
        $privateKey = trim((string)($config['merchant_private_key'] ?? ''));

        if ($appAuthToken === '' && ($appId === '' || $privateKey === '')) {
            return ['code' => -1, 'msg' => '请点击上方「扫码一键绑定」或至少填写有效的支付宝 AppID 与应用私钥'];
        }

        return ['code' => 1, 'data' => $config];
    }
}
