<?php

declare(strict_types=1);

namespace app\payment\Drivers\AlipayCookieCloud;

use app\payment\Contracts\PaymentDriverInterface;
use app\payment\Contracts\MonitorableDriverInterface;
use app\payment\Contracts\AccountAuthorizationInterface;
use app\payment\Contracts\ServerPollingDriverInterface;
use InvalidArgumentException;
use Throwable;

/**
 * 支付宝扫码免挂 / Cookie 账单轮询插件驱动
 * 
 * 核心实现（对标同类商用成熟方案）：
 * 1. 支持手机支付宝一键扫码自动授权，Cookie 自动 Base64 安全编码入库；
 * 2. 支持「支付宝账号验证（收款人姓氏校验）」，自动通过异地/跨设备安全风控；
 * 3. 采用轻量高性能的 mbillexprod JSON 账单 API + standard.htm 双通道轮询，毫秒级对账与回调。
 */
class Driver implements PaymentDriverInterface, MonitorableDriverInterface, AccountAuthorizationInterface, ServerPollingDriverInterface
{
    public function monitorMode(): string
    {
        return MonitorableDriverInterface::MODE_SERVER;
    }

    public function pay(array $params, array $config): array
    {
        $qrCodeUrl = trim((string)($config['qr_code_url'] ?? ''));
        if ($qrCodeUrl === '') {
            throw new InvalidArgumentException('请先配置支付宝固定收款码图片或二维码解析链接');
        }

        $money = number_format((float)($params['money'] ?? 0), 2, '.', '');
        $tradeNo = (string)($params['trade_no'] ?? '');

        return [
            'type'        => 'qrcode',
            'qrcode'      => $qrCodeUrl,
            'pay_url'     => $qrCodeUrl,
            'trade_no'    => $tradeNo,
            'real_money'  => $money,
            'mode'        => 'cookie_cloud',
            'instruction' => '请使用手机支付宝扫描上方二维码，输入或核对指定金额完成支付',
        ];
    }

    public function notify(array $params, array $config): array
    {
        $tradeNo = (string)($params['trade_no'] ?? $params['out_trade_no'] ?? '');
        $channelTradeNo = (string)($params['alipay_trade_no'] ?? $params['channel_trade_no'] ?? '');
        $amount = (float)($params['amount'] ?? $params['money'] ?? 0);

        if ($tradeNo === '' || $amount <= 0) {
            return ['code' => -1, 'msg' => '无效的回调参数'];
        }

        return [
            'code'             => 1,
            'msg'              => 'success',
            'trade_no'         => $tradeNo,
            'channel_trade_no' => $channelTradeNo,
            'amount'           => $amount,
            'status'           => 'TRADE_SUCCESS',
            'pay_type'         => 'alipay',
        ];
    }

    /**
     * 智能还原 Cookie（自动识别 Base64 编码或原生明文）
     */
    private function resolveCookie(array $config): string
    {
        $raw = trim((string)($config['cookie'] ?? ''));
        if ($raw === '') {
            return '';
        }

        // 自动解密系统敏感存储密文 (v2: / v1:)
        if (str_starts_with($raw, 'v2:') || str_starts_with($raw, 'v1:')) {
            try {
                $authcode = new \support\Authcode();
                $raw = $authcode->decryptStored($raw);
            } catch (\Throwable) {}
        }

        $decoded = @base64_decode($raw, true);
        if ($decoded !== false && (str_contains($decoded, 'ALIPAYJSESSIONID') || str_contains($decoded, 'ctoken') || str_contains($decoded, 'zone=') || str_contains($decoded, 'CLUB_ALIPAY_COM'))) {
            return trim($decoded);
        }

        return $raw;
    }

    /**
     * 支付宝轻量级 Session 保活机制
     * 仅访问个人控制台与账单主域维持 Session 活跃，严禁请求企业域（避免重置个人 Session Cookie）
     *
     * @param string $cookie 已解析的明文 Cookie 字符串
     */
    private function keepAlive(string $cookie): void
    {
        $lockFile = sys_get_temp_dir() . '/alipay_keepalive_' . md5(substr($cookie, 0, 64)) . '.lock';
        $lastRun  = (int)@file_get_contents($lockFile);
        // 节流：5 分钟内已保活过则跳过
        if ($lastRun > 0 && (time() - $lastRun) < 300) {
            return;
        }
        @file_put_contents($lockFile, (string)time());

        $ua = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36';

        // 仅对个人门户和标准消费明细发起安全心跳
        $heartbeatUrls = [
            'https://my.alipay.com/portal/i.htm',
            'https://consumeprod.alipay.com/record/standard.htm',
        ];
        foreach ($heartbeatUrls as $url) {
            try {
                $ch = curl_init($url);
                curl_setopt_array($ch, [
                    CURLOPT_RETURNTRANSFER => true,
                    CURLOPT_FOLLOWLOCATION => true,
                    CURLOPT_MAXREDIRS      => 3,
                    CURLOPT_TIMEOUT        => 6,
                    CURLOPT_CONNECTTIMEOUT => 3,
                    CURLOPT_SSL_VERIFYPEER => false,
                    CURLOPT_SSL_VERIFYHOST => false,
                    CURLOPT_USERAGENT      => $ua,
                    CURLOPT_HTTPHEADER     => [
                        'Cookie: ' . $cookie,
                        'Referer: https://my.alipay.com/',
                        'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
                        'Accept-Language: zh-CN,zh;q=0.9',
                    ],
                ]);
                curl_exec($ch);
                curl_close($ch);
            } catch (\Throwable) {
                // 心跳异常静默忽略
            }
        }
    }

    /**
     * 服务端账单轮询核心契约实现（个人消费明细 + 企业账单双引擎）
     *
     * @return list<array{
     *   source_bill_id:string,
     *   amount:string,
     *   occurred_at:int,
     *   remark?:string,
     *   raw_hash?:string
     * }>
     */
    public function pollPaymentEvents(array $config, int $since, int $until): array
    {
        $cookie = $this->resolveCookie($config);
        if ($cookie === '') {
            return [];
        }

        // 执行节流轻量级保活
        $this->keepAlive($cookie);

        $ctoken = '';
        if (preg_match('/(?:^|;\s*)ctoken=([^;]+)/', $cookie, $m)) {
            $ctoken = trim($m[1]);
        }

        $ua = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36';
        $events = [];

        $isExplicitLoggedOut = false;

        // 引擎 1（主力）：支付宝个人全量收支明细（lab.alipay.com，实测唯一直连稳定的个人对账标准接口）
        try {
            $ch = curl_init('https://lab.alipay.com/consume/record/items.htm');
            curl_setopt_array($ch, [
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_HEADER         => true, // 捕获响应头以提取 Set-Cookie 自动续期
                CURLOPT_FOLLOWLOCATION => true,
                CURLOPT_MAXREDIRS      => 4,
                CURLOPT_TIMEOUT        => 8,
                CURLOPT_SSL_VERIFYPEER => false,
                CURLOPT_SSL_VERIFYHOST => false,
                CURLOPT_USERAGENT      => $ua,
                CURLOPT_HTTPHEADER     => [
                    'Cookie: ' . $cookie,
                    'Referer: https://my.alipay.com/portal/i.htm',
                    'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8',
                    'Accept-Language: zh-CN,zh;q=0.9',
                ],
            ]);
            $rawResponse = (string)curl_exec($ch);
            $headerSize = curl_getinfo($ch, CURLINFO_HEADER_SIZE);
            $effUrl = (string)curl_getinfo($ch, CURLINFO_EFFECTIVE_URL);
            curl_close($ch);

            $responseHeaders = substr($rawResponse, 0, $headerSize);
            $labHtml = substr($rawResponse, $headerSize);

            // 自动捕获支付宝网关下发的新 Session 凭据进行滑动续期
            $this->updateRefreshedCookies($config, $responseHeaders);

            if (is_string($labHtml) && strlen($labHtml) > 500) {
                if (str_contains($effUrl, 'auth.alipay.com/login') || str_contains($effUrl, 'login.alipay.com')) {
                    $isExplicitLoggedOut = true;
                } else {
                    $utf8 = mb_convert_encoding($labHtml, 'UTF-8', 'GB18030,GBK,GB2312,UTF-8');
                    preg_match_all('/<tr[^>]*>(.*?)<\/tr>/si', $utf8, $trs);

                    foreach ($trs[0] ?? [] as $trHtml) {
                        $text = preg_replace('/\s+/', ' ', strip_tags($trHtml));
                        if (!preg_match('/([0-9]{18,64})\s+([0-9]{4}-[0-9]{2}-[0-9]{2}\s+[0-9]{2}:[0-9]{2}:[0-9]{2})\s+(.*?)\s+([0-9]+\.[0-9]{2})\s+(&nbsp;|\s+)/', $text, $m)) {
                            continue;
                        }

                        $tradeNo = trim($m[1]);
                        $timeStr = trim($m[2]);
                        $title = trim($m[3]);
                        $income = trim($m[4]);
                        $occurredAt = strtotime($timeStr) ?: time();

                        $events[] = [
                            'source_bill_id' => $tradeNo,
                            'amount'         => number_format((float)$income, 2, '.', ''),
                            'occurred_at'    => $occurredAt,
                            'remark'         => $title,
                            'raw_hash'       => md5($tradeNo . $income . $occurredAt),
                        ];
                    }

                    if (!empty($events)) {
                        return $this->filterEventsByWindow($events, $since, $until);
                    }
                }
            }
        } catch (\Throwable) {
            // 继续降级
        }

        // 引擎 2（备用）：支付宝个人消费记录备用页（standard.htm / advanced.htm）
        $targetUrls = [];
        if ($ctoken !== '') {
            $targetUrls[] = 'https://consumeprod.alipay.com/record/standard.htm?_output_charset=utf-8&ctoken=' . urlencode($ctoken);
            $targetUrls[] = 'https://consumeprod.alipay.com/record/advanced.htm?_output_charset=utf-8&ctoken=' . urlencode($ctoken);
        }
        $targetUrls[] = 'https://consumeprod.alipay.com/record/standard.htm';
        $targetUrls[] = 'https://consumeprod.alipay.com/record/advanced.htm';

        foreach ($targetUrls as $queryUrl) {
            try {
                $ch = curl_init($queryUrl);
                curl_setopt_array($ch, [
                    CURLOPT_RETURNTRANSFER => true,
                    CURLOPT_FOLLOWLOCATION => true,
                    CURLOPT_MAXREDIRS      => 5,
                    CURLOPT_TIMEOUT        => 10,
                    CURLOPT_SSL_VERIFYPEER => false,
                    CURLOPT_SSL_VERIFYHOST => false,
                    CURLOPT_USERAGENT      => $ua,
                    CURLOPT_HTTPHEADER     => [
                        'Cookie: ' . $cookie,
                        'Referer: https://my.alipay.com/',
                        'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8',
                        'Accept-Language: zh-CN,zh;q=0.9',
                    ],
                ]);
                $body = curl_exec($ch);
                $effUrl = (string)curl_getinfo($ch, CURLINFO_EFFECTIVE_URL);
                curl_close($ch);

                if (!is_string($body) || $body === '') {
                    continue;
                }

                // 确凿重定向到登录页判定失效
                if (str_contains($effUrl, 'auth.alipay.com/login') || str_contains($effUrl, 'login.alipay.com')) {
                    $isExplicitLoggedOut = true;
                    continue;
                }

                $utf8 = mb_convert_encoding($body, 'UTF-8', 'GB18030,GBK,GB2312,UTF-8');
                preg_match_all('/<tr[^>]*>(.*?)<\/tr>/si', $utf8, $trs);

                foreach ($trs[0] ?? [] as $trHtml) {
                    $trText = preg_replace('/\s+/', ' ', strip_tags($trHtml));
                    if (!str_contains($trText, '+') && !str_contains($trText, '收钱码') && !str_contains($trText, '交易号') && !str_contains($trText, '订单号')) {
                        continue;
                    }

                    // 1. 提取流水发生时间
                    $occurredAt = time();
                    if (preg_match('/(\d{4}[\.\-/]\d{2}[\.\-/]\d{2}\s+\d{2}:\d{2}(?::\d{2})?)/', $trText, $timeM)) {
                        $rawTime = str_replace('.', '-', $timeM[1]);
                        $occurredAt = strtotime($rawTime) ?: time();
                    }

                    // 2. 提取交易号 / 订单号
                    $tradeNo = '';
                    if (preg_match('/交易号[:：]\s*([0-9]{16,64})/', $trText, $mTrade)) {
                        $tradeNo = trim($mTrade[1]);
                    } elseif (preg_match('/订单号[:：]\s*([A-Za-z0-9_\-]+)/', $trText, $mOrder)) {
                        $tradeNo = trim($mOrder[1]);
                    }

                    // 3. 提取收入金额
                    $cleanAmount = '0.00';
                    if (preg_match('/\+\s*([0-9]+(?:\.[0-9]{1,2})?)/', $trText, $mAmt)) {
                        $cleanAmount = number_format((float)$mAmt[1], 2, '.', '');
                    }

                    // 4. 提取备注
                    $remark = '收钱码收款';
                    if (preg_match('/(收钱码收款|通道连通性测试|扫码支付|转账)/', $trText, $mRem)) {
                        $remark = $mRem[1];
                    }

                    if ((float)$cleanAmount > 0 && $tradeNo !== '') {
                        $events[] = [
                            'source_bill_id' => $tradeNo,
                            'amount'         => $cleanAmount,
                            'occurred_at'    => $occurredAt,
                            'remark'         => $remark,
                            'raw_hash'       => md5($tradeNo . $cleanAmount . $occurredAt),
                        ];
                    }
                }

                if (!empty($events)) {
                    return $this->filterEventsByWindow($events, $since, $until);
                }
            } catch (\Throwable) {
                // 继续尝试
            }
        }

        // 引擎 2：支付宝商家中心 JSON API（针对企业版商户）
        try {
            $jsonUrl = 'https://mbillexprod.alipay.com/enterprise/tradeListQuery.json?precisionQueryKey=tradeNo&sortTarget=gmtCreate&sortType=0&pageSize=20&pageNum=1&total=1';
            if ($ctoken !== '') {
                $jsonUrl .= '&ctoken=' . urlencode($ctoken);
            }

            $ch = curl_init($jsonUrl);
            curl_setopt_array($ch, [
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_FOLLOWLOCATION => true,
                CURLOPT_MAXREDIRS      => 3,
                CURLOPT_TIMEOUT        => 8,
                CURLOPT_SSL_VERIFYPEER => false,
                CURLOPT_SSL_VERIFYHOST => false,
                CURLOPT_USERAGENT      => $ua,
                CURLOPT_HTTPHEADER     => [
                    'Cookie: ' . $cookie,
                    'Referer: https://mbillexprod.alipay.com/enterprise/tradeList.htm',
                    'Accept: application/json, text/javascript, */*; q=0.01',
                    'X-Requested-With: XMLHttpRequest',
                ],
            ]);
            $jsonRes = curl_exec($ch);
            curl_close($ch);

            if (is_string($jsonRes) && str_starts_with(trim($jsonRes), '{')) {
                $data = json_decode($jsonRes, true) ?: [];
                $list = $data['result']['tradeList'] ?? $data['tradeList'] ?? $data['result'] ?? [];
                if (is_array($list) && !empty($list)) {
                    foreach ($list as $item) {
                        $tradeNo = (string)($item['tradeNo'] ?? $item['trade_no'] ?? $item['orderNo'] ?? '');
                        $rawAmount = (string)($item['tradeAmount'] ?? $item['amount'] ?? $item['totalAmount'] ?? '0');
                        $rawTime = (string)($item['gmtCreate'] ?? $item['tradeTime'] ?? $item['gmtPayment'] ?? '');
                        $memo = (string)($item['tradeMemo'] ?? $item['memo'] ?? $item['goodsTitle'] ?? '收钱码收款');

                        if (str_contains($rawAmount, '-')) {
                            continue;
                        }

                        if (preg_match('/([\d\.]+)/', str_replace(['+', ' ', '¥', '￥'], '', $rawAmount), $am)) {
                            $cleanAmount = number_format((float)$am[1], 2, '.', '');
                            $cleanTime = str_replace(['.', '/'], '-', $rawTime);
                            $occurredAt = $cleanTime !== '' ? (strtotime($cleanTime) ?: time()) : time();

                            if ($tradeNo === '') {
                                $tradeNo = 'ALI_' . md5($rawTime . '_' . $cleanAmount . '_' . $memo);
                            }

                            $events[] = [
                                'source_bill_id' => $tradeNo,
                                'amount'         => $cleanAmount,
                                'occurred_at'    => $occurredAt,
                                'remark'         => $memo,
                                'raw_hash'       => md5($tradeNo . $cleanAmount . $occurredAt),
                            ];
                        }
                    }
                    if (!empty($events)) {
                        return $this->filterEventsByWindow($events, $since, $until);
                    }
                }
            }
        } catch (\Throwable) {
            // 静默
        }

        // 引擎 4：本地驻留 Chromium 无头浏览器抓取（针对开通商户版或具有动态 JS 渲染与重定向拦截的场景）
        try {
            $bCh = curl_init('http://127.0.0.1:9527/api/ali/records');
            curl_setopt_array($bCh, [
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_POST           => true,
                CURLOPT_POSTFIELDS     => json_encode(['cookie' => $cookie]),
                CURLOPT_HTTPHEADER     => ['Content-Type: application/json'],
                CURLOPT_TIMEOUT        => 12,
                CURLOPT_CONNECTTIMEOUT => 2,
            ]);
            $bResp = curl_exec($bCh);
            $bCode = curl_getinfo($bCh, CURLINFO_HTTP_CODE);
            curl_close($bCh);
            if ($bCode === 200 && !empty($bResp)) {
                $bJson = json_decode((string)$bResp, true);
                $bEvents = $bJson['events'] ?? [];
                if (is_array($bEvents) && !empty($bEvents)) {
                    foreach ($bEvents as $bev) {
                        $events[] = [
                            'source_bill_id' => (string)($bev['source_bill_id'] ?? ''),
                            'amount'         => (string)($bev['amount'] ?? '0.00'),
                            'occurred_at'    => (int)($bev['occurred_at'] ?? time()),
                            'remark'         => (string)($bev['remark'] ?? '收钱码收款'),
                            'raw_hash'       => (string)($bev['raw_hash'] ?? md5($bev['source_bill_id'])),
                        ];
                    }
                    if (!empty($events)) {
                        return $this->filterEventsByWindow($events, $since, $until);
                    }
                }
            }
        } catch (\Throwable) {
            // 忽略微服务调用异常
        }

        if ($isExplicitLoggedOut) {
            throw new \RuntimeException('支付宝 Cookie 已失效（检测到重定向至登录页），请重新扫码授权');
        }

        return $events;
    }

    /**
     * 按时间窗口过滤账单事件（Bug #3 修复）
     *
     * 兼容逻辑：若窗口过大（>24h）或事件 occurred_at 均在窗口外但 $since=0，
     * 则返回全部事件，避免因时区/解析偏差导致合法账单被全部过滤。
     *
     * @param list<array{source_bill_id:string,amount:string,occurred_at:int,...}> $events
     */
    private function filterEventsByWindow(array $events, int $since, int $until): array
    {
        if ($since <= 0 || $until <= 0 || ($until - $since) >= 86400) {
            // 窗口为 0 或超过 24 小时，不过滤直接返回（调用方应自行去重）
            return $events;
        }

        // 放宽 5 分钟容差，对抗支付宝服务端时间与本地时间轻微偏差
        $tolerance = 300;
        $filtered = array_filter($events, static function (array $e) use ($since, $until, $tolerance): bool {
            $t = (int)($e['occurred_at'] ?? 0);
            return $t > 0 && $t >= ($since - $tolerance) && $t <= ($until + $tolerance);
        });

        // 若过滤后为空，可能是 occurred_at 全部回退成 time()，此时放行所有以防漏单
        return count($filtered) > 0 ? array_values($filtered) : $events;
    }

    /**
     * 解析并合并响应头中的 Set-Cookie，执行自动滑动续期
     */
    private function updateRefreshedCookies(array $config, string $responseHeaders): void
    {
        if (!preg_match_all('/^set-cookie:\s*([^;\r\n]+)/im', $responseHeaders, $mCookies)) {
            return;
        }

        $currentCookie = $this->resolveCookie($config);
        $cookieMap = [];
        foreach (explode(';', $currentCookie) as $pair) {
            $parts = explode('=', trim($pair), 2);
            if (count($parts) === 2) {
                $k = trim($parts[0]);
                $v = trim($parts[1]);
                if ($k !== '' && $v !== '') {
                    $cookieMap[$k] = $v;
                }
            }
        }

        $hasUpdates = false;
        foreach ($mCookies[1] as $cStr) {
            $parts = explode('=', trim($cStr), 2);
            if (count($parts) === 2) {
                $k = trim($parts[0]);
                $v = trim($parts[1]);
                if ($k !== '' && $v !== '' && $v !== 'deleted' && !in_array($k, ['LoginForm', 'auth_goto_http_type'], true)) {
                    if (!isset($cookieMap[$k]) || $cookieMap[$k] !== $v) {
                        $cookieMap[$k] = $v;
                        if (in_array($k, ['ALIPAYJSESSIONID', 'zone', 'spanner', 'ctoken', 'CLUB_ALIPAY_COM'], true)) {
                            $hasUpdates = true;
                        }
                    }
                }
            }
        }

        if ($hasUpdates && !empty($config['__channel_id'])) {
            $channelId = (int)$config['__channel_id'];
            $channel = \app\model\Channel::find($channelId);
            if ($channel) {
                $mergedCookie = '';
                foreach ($cookieMap as $k => $v) {
                    $mergedCookie .= "{$k}={$v}; ";
                }
                $mergedCookie = trim($mergedCookie, '; ');
                $base64 = base64_encode($mergedCookie);

                $cfg = json_decode((string)$channel->config, true) ?: [];
                $authcode = new \support\Authcode();
                $cfg['cookie'] = $authcode->encrypt($base64);
                $channel->config = json_encode($cfg, JSON_UNESCAPED_UNICODE);
                $channel->save();
            }
        }
    }

    public function query(string $tradeNo, array $config): array
    {
        // 1. 获取待核销订单信息
        $order = \app\model\Order::where('trade_no', $tradeNo)->first();
        if (!$order) {
            return ['paid' => false, 'trade_no' => $tradeNo, 'status' => 'listening'];
        }

        // 若订单已在后台被核销成功，直接返回成功状态（0ms 响应，不卡顿）
        if ((int)$order->status === 1 || (int)$order->status === 2) {
            return [
                'paid'             => true,
                'trade_no'         => $tradeNo,
                'channel_trade_no' => (string)($order->channel_trade_no ?? ''),
                'amount'           => (float)($order->real_money ?: $order->amount ?: $order->price),
                'status'           => 'TRADE_SUCCESS',
                'message'          => '支付成功',
            ];
        }

        $orderMoney = (float)($order->price ?: $order->amount ?: $order->money ?: 0);
        $orderCreateTime = (int)($order->create_time ?: time());

        // 2. 毫秒级优先查询本地 Callbill 表（由后台常驻定时器采集，不阻塞 HTTP 进程）
        $matchedBill = \app\model\Callbill::where('channel_id', (int)$order->channel_id)
            ->where('occurred_at', '>=', $orderCreateTime - 120)
            ->where(function ($q) use ($orderMoney, $tradeNo) {
                $q->where('money', $orderMoney)
                  ->orWhere('remark', 'like', "%{$tradeNo}%")
                  ->orWhere('source_bill_id', 'like', "%{$tradeNo}%");
            })
            ->orderBy('id', 'desc')
            ->first();

        if ($matchedBill) {
            return [
                'paid'             => true,
                'trade_no'         => $tradeNo,
                'channel_trade_no' => (string)$matchedBill->source_bill_id,
                'amount'           => (float)$matchedBill->money,
                'status'           => 'TRADE_SUCCESS',
                'message'          => '支付宝免挂实时流水核销成功',
            ];
        }

        // 3. 节流保护：前端 1 秒 1 次的高频轮询绝不执行远程重型 cURL/浏览器抓取，避免打满 Webman 进程
        $throttleKey = sys_get_temp_dir() . '/ali_query_throttle_' . md5($tradeNo);
        $lastRemoteCheck = (int)@file_get_contents($throttleKey);
        if (time() - $lastRemoteCheck < 6) {
            return ['paid' => false, 'trade_no' => $tradeNo, 'status' => 'listening'];
        }
        @file_put_contents($throttleKey, (string)time());

        $cookie = $this->resolveCookie($config);
        if ($cookie === '') {
            return ['paid' => false, 'trade_no' => $tradeNo, 'msg' => '未配置支付宝 Cookie'];
        }

        return ['paid' => false, 'trade_no' => $tradeNo, 'status' => 'listening'];
    }

    /**
     * 发起支付宝扫码授权提取 Cookie（支持无头浏览器两阶段 CDP 抓取与官方协议）
     */
    public function startAccountAuthorization(array $config): array
    {
        $sessionId = 'ali_ck_' . bin2hex(random_bytes(12));
        $cacheDir = runtime_path() . '/auth_sessions';
        if (!is_dir($cacheDir)) {
            @mkdir($cacheDir, 0777, true);
        }

        $cookieJar = $cacheDir . '/' . $sessionId . '.cookie';
        @unlink($cookieJar);

        // 优先调用本地扫码微服务 (Puppeteer 两阶段安全授权)
        $browserMicroserviceUrl = 'http://127.0.0.1:9527/api/ali/start?session_id=' . urlencode($sessionId);
        $bCh = curl_init($browserMicroserviceUrl);
        curl_setopt_array($bCh, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT        => 25,
            CURLOPT_CONNECTTIMEOUT => 3,
        ]);
        $bResp = curl_exec($bCh);
        $bCode = curl_getinfo($bCh, CURLINFO_HTTP_CODE);
        curl_close($bCh);

        if ($bCode === 200 && !empty($bResp)) {
            $bJson = json_decode((string)$bResp, true);
            if (($bJson['code'] ?? -1) === 0 && !empty($bJson['qr_url'])) {
                $sessionData = [
                    'session_id'   => $sessionId,
                    'status'       => 'QR_READY',
                    'qr_url'       => $bJson['qr_url'],
                    'security_id'  => 'browser_microservice',
                    'verify_name'  => trim((string)($config['verify_name'] ?? '')),
                    'created_at'   => time(),
                    'expires_at'   => time() + 300,
                    'cookie'       => '',
                ];
                @file_put_contents("{$cacheDir}/{$sessionId}.json", json_encode($sessionData, JSON_UNESCAPED_UNICODE));

                return [
                    'status'     => 'QR_READY',
                    'session_id' => $sessionId,
                    'qr_url'     => $bJson['qr_url'],
                    'expires_at' => $sessionData['expires_at'],
                    'message'    => '请用手机支付宝 App 扫描二维码登录，系统将自动提取全量账单 Cookie',
                ];
            }
        }

        // 兜底：请求支付宝官方统一登录页
        $ua = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36';
        $ch = curl_init('https://auth.alipay.com/login/index.htm');
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_MAXREDIRS      => 5,
            CURLOPT_TIMEOUT        => 8,
            CURLOPT_CONNECTTIMEOUT => 3,
            CURLOPT_SSL_VERIFYPEER => false,
            CURLOPT_SSL_VERIFYHOST => false,
            CURLOPT_USERAGENT      => $ua,
            CURLOPT_COOKIEJAR      => $cookieJar,
            CURLOPT_COOKIEFILE     => $cookieJar,
        ]);
        $html = (string)curl_exec($ch);
        curl_close($ch);

        $qrUrl = '';
        $securityId = '';

        if (preg_match('/(https:\/\/qr\.alipay\.com\/[^"\'\s<>]+)/i', $html, $mQr)) {
            $qrUrl = str_replace('&amp;', '&', $mQr[1]);
        }
        if (preg_match('/securityId=([^"\'\s&<>]+)/i', $qrUrl, $mSec)
            || preg_match('/["\']?securityId["\']?\s*[:=]\s*["\']([^"\'\s]+)["\']/i', $html, $mSec)) {
            $rawSec = (string)$mSec[1];
            while (str_contains($rawSec, '%25')) {
                $rawSec = urldecode($rawSec);
            }
            $securityId = urldecode($rawSec);
        }

        if ($qrUrl !== '' && $securityId !== '') {
            $sessionData = [
                'session_id'   => $sessionId,
                'status'       => 'QR_READY',
                'qr_url'       => $qrUrl,
                'security_id'  => $securityId,
                'verify_name'  => trim((string)($config['verify_name'] ?? '')),
                'cookie_jar'   => $cookieJar,
                'created_at'   => time(),
                'expires_at'   => time() + 300,
                'cookie'       => '',
            ];
            @file_put_contents("{$cacheDir}/{$sessionId}.json", json_encode($sessionData, JSON_UNESCAPED_UNICODE));

            return [
                'status'     => 'QR_READY',
                'session_id' => $sessionId,
                'qr_url'     => $qrUrl,
                'expires_at' => $sessionData['expires_at'],
                'message'    => '请用手机支付宝 App 扫描二维码登录，系统将全自动提取账单 Cookie',
            ];
        }

        return [
            'status'     => 'FAILED',
            'session_id' => $sessionId,
            'qr_url'     => '',
            'message'    => '获取登录二维码失败，请刷新后重试',
        ];
    }

    /**
     * 轮询扫码授权状态（支持姓名姓氏校验与 Base64 编码保存）
     */
    public function pollAccountAuthorization(string $sessionId, array $config): array
    {
        $cacheDir = runtime_path() . '/auth_sessions';
        $sessionFile = "{$cacheDir}/{$sessionId}.json";

        if (!file_exists($sessionFile)) {
            return ['status' => 'EXPIRED', 'message' => '授权会话不存在或已过期，请重新扫码'];
        }

        $sessionData = json_decode((string)file_get_contents($sessionFile), true) ?: [];
        if (time() > ($sessionData['expires_at'] ?? 0)) {
            @unlink($sessionFile);
            if (!empty($sessionData['cookie_jar'])) { @unlink($sessionData['cookie_jar']); }
            return ['status' => 'EXPIRED', 'message' => '扫码会话已超时，请重新点击扫码'];
        }

        // 优先轮询微服务（支持两阶段安全校验状态机）
        if (($sessionData['security_id'] ?? '') === 'browser_microservice') {
            $statusUrl = 'http://127.0.0.1:9527/api/ali/status?session_id=' . urlencode($sessionId);
            $bCh = curl_init($statusUrl);
            curl_setopt_array($bCh, [
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_TIMEOUT        => 5,
            ]);
            $bResp = curl_exec($bCh);
            curl_close($bCh);

            if (!empty($bResp)) {
                $bJson = json_decode((string)$bResp, true);
                if (($bJson['status'] ?? '') === 'need_second_scan') {
                    return [
                        'status'        => 'NEED_SECOND_SCAN',
                        'message'       => '登录成功！请再次使用手机扫描下方安全确认二维码（解除消费明细查看限制）',
                        'qr_url'        => $bJson['qr_url'] ?? '',
                        'cookie'        => $bJson['cookie_base64'] ?? '',
                        'cookie_base64' => $bJson['cookie_base64'] ?? '',
                    ];
                }
                if (($bJson['status'] ?? '') === 'confirmed' && !empty($bJson['cookie_base64'])) {
                    $base64Cookie = (string)$bJson['cookie_base64'];
                    @unlink($sessionFile);
                    return [
                        'status'        => 'CONFIRMED',
                        'message'       => '🎉 支付宝两阶段扫码授权成功，已自动提取并保存全量账单 Cookie！',
                        'cookie'        => $base64Cookie,
                        'cookie_base64' => $base64Cookie,
                        'config_patch'  => ['cookie' => $base64Cookie, 'cookie_base64' => $base64Cookie],
                    ];
                }
                if (($bJson['status'] ?? '') === 'timeout') {
                    @unlink($sessionFile);
                    return ['status' => 'EXPIRED', 'message' => '扫码会话已超时，请重新点击扫码'];
                }
            }
            return [
                'status'  => 'WAITING',
                'message' => '等待手机支付宝扫码并确认登录...',
            ];
        }

        if (!empty($sessionData['cookie'])) {
            $base64Cookie = (string)$sessionData['cookie'];
            @unlink($sessionFile);
            if (!empty($sessionData['cookie_jar'])) { @unlink($sessionData['cookie_jar']); }
            return [
                'status'        => 'CONFIRMED',
                'message'       => '🎉 支付宝扫码登录成功，已自动提取并编码保存商家 Cookie！',
                'cookie'        => $base64Cookie,
                'cookie_base64' => $base64Cookie,
                'config_patch'  => ['cookie' => $base64Cookie, 'cookie_base64' => $base64Cookie],
            ];
        }

        $securityId = (string)($sessionData['security_id'] ?? '');
        while (str_contains($securityId, '%25')) {
            $securityId = urldecode($securityId);
        }
        $verifyName = trim((string)($config['verify_name'] ?? $sessionData['verify_name'] ?? ''));
        $cookieJar = $sessionData['cookie_jar'] ?? "{$cacheDir}/{$sessionId}.cookie";
        $ua = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36';

        if ($securityId !== '') {
            try {
                $callbackName = 'light.page.products.barcode.processStatus';
                $ts = (int)(microtime(true) * 1000);
                $pollUrl = 'https://securitycore.alipay.com/barcode/barcodeProcessStatus.json?securityId=' . urlencode($securityId) . '&_callback=' . $callbackName . '&_ksTS=' . $ts . '_' . mt_rand(100, 999);

                $ch = curl_init($pollUrl);
                curl_setopt_array($ch, [
                    CURLOPT_RETURNTRANSFER => true,
                    CURLOPT_HEADER         => false,
                    CURLOPT_TIMEOUT        => 6,
                    CURLOPT_SSL_VERIFYPEER => false,
                    CURLOPT_SSL_VERIFYHOST => false,
                    CURLOPT_USERAGENT      => $ua,
                    CURLOPT_COOKIEJAR      => $cookieJar,
                    CURLOPT_COOKIEFILE     => $cookieJar,
                    CURLOPT_HTTPHEADER     => [
                        'Referer: https://auth.alipay.com/login/index.htm',
                    ],
                ]);
                $bodyStr = (string)curl_exec($ch);
                curl_close($ch);

                $pollRes = [];
                if (preg_match('/\{.*\}/s', $bodyStr, $jm)) {
                    $pollRes = json_decode($jm[0], true) ?: [];
                }

                $barcodeStatus = strtolower((string)($pollRes['barcodeStatus'] ?? $pollRes['status'] ?? ''));
                $targetUrl = trim((string)($pollRes['targetUrl'] ?? ''));

                if ($verifyName !== '' && (str_contains($barcodeStatus, 'verify') || str_contains($barcodeStatus, 'name') || ($pollRes['needVerifyName'] ?? false))) {
                    try {
                        $verifyCh = curl_init('https://securitycore.alipay.com/barcode/checkName.json');
                        curl_setopt_array($verifyCh, [
                            CURLOPT_RETURNTRANSFER => true,
                            CURLOPT_HEADER         => false,
                            CURLOPT_POST           => true,
                            CURLOPT_POSTFIELDS     => http_build_query([
                                'securityId' => $securityId,
                                'checkName'  => $verifyName,
                            ]),
                            CURLOPT_TIMEOUT        => 6,
                            CURLOPT_SSL_VERIFYPEER => false,
                            CURLOPT_SSL_VERIFYHOST => false,
                            CURLOPT_USERAGENT      => $ua,
                            CURLOPT_COOKIEJAR      => $cookieJar,
                            CURLOPT_COOKIEFILE     => $cookieJar,
                        ]);
                        curl_exec($verifyCh);
                        curl_close($verifyCh);
                    } catch (\Throwable) {}
                }

                $isConfirmed = ($targetUrl !== '') || in_array($barcodeStatus, ['confirmed', 'confirm_success', 'success'], true);
                if ($isConfirmed) {
                    if ($targetUrl === '') {
                        $targetUrl = 'https://auth.alipay.com/login/index.htm?loginFormMethod=qrCodeLogin&securityId=' . urlencode($securityId);
                    }

                    // 跑完换票与全局登录重定向链
                    $loginCh = curl_init($targetUrl);
                    curl_setopt_array($loginCh, [
                        CURLOPT_RETURNTRANSFER => true,
                        CURLOPT_HEADER         => false,
                        CURLOPT_FOLLOWLOCATION => true,
                        CURLOPT_MAXREDIRS      => 6,
                        CURLOPT_TIMEOUT        => 10,
                        CURLOPT_SSL_VERIFYPEER => false,
                        CURLOPT_SSL_VERIFYHOST => false,
                        CURLOPT_USERAGENT      => $ua,
                        CURLOPT_COOKIEJAR      => $cookieJar,
                        CURLOPT_COOKIEFILE     => $cookieJar,
                        CURLOPT_HTTPHEADER     => [
                            'Referer: https://auth.alipay.com/login/index.htm',
                        ],
                    ]);
                    $loginBody = (string)curl_exec($loginCh);
                    curl_close($loginCh);

                    // 自动提交跨域授权 POST 表单
                    if (preg_match('/<form[^>]*action=["\']([^"\']+)["\'][^>]*>(.*?)<\/form>/si', $loginBody, $formMatch)) {
                        $formAction = trim($formMatch[1]);
                        if (!str_starts_with($formAction, 'http')) {
                            $formAction = 'https://auth.alipay.com' . (str_starts_with($formAction, '/') ? '' : '/') . $formAction;
                        }
                        preg_match_all('/<input[^>]*name=["\']([^"\']+)["\'][^>]*value=["\']([^"\']*)["\']/si', $formMatch[2], $inputMatches, PREG_SET_ORDER);
                        $postFields = [];
                        foreach ($inputMatches as $inp) {
                            $postFields[$inp[1]] = html_entity_decode($inp[2]);
                        }
                        if (!empty($postFields)) {
                            $formCh = curl_init($formAction);
                            curl_setopt_array($formCh, [
                                CURLOPT_RETURNTRANSFER => true,
                                CURLOPT_HEADER         => false,
                                CURLOPT_POST           => true,
                                CURLOPT_POSTFIELDS     => http_build_query($postFields),
                                CURLOPT_FOLLOWLOCATION => true,
                                CURLOPT_MAXREDIRS      => 6,
                                CURLOPT_TIMEOUT        => 10,
                                CURLOPT_SSL_VERIFYPEER => false,
                                CURLOPT_SSL_VERIFYHOST => false,
                                CURLOPT_USERAGENT      => $ua,
                                CURLOPT_COOKIEJAR      => $cookieJar,
                                CURLOPT_COOKIEFILE     => $cookieJar,
                                CURLOPT_HTTPHEADER     => [
                                    'Referer: https://auth.alipay.com/login/index.htm',
                                    'Content-Type: application/x-www-form-urlencoded',
                                ],
                            ]);
                            curl_exec($formCh);
                            curl_close($formCh);
                        }
                    }

                    // 自动跟踪 JavaScript 跳转或 Meta Refresh
                    if (preg_match('/(?:window\.location(?:\.replace|\.href)?|location\.href)\s*=\s*["\']([^"\']+)["\']/i', $loginBody, $jsMatch)
                        || preg_match('/<meta[^>]*http-equiv=["\']refresh["\'][^>]*content=["\'][^;]*;\s*url=([^"\']+)["\']/i', $loginBody, $jsMatch)) {
                        $jsUrl = trim($jsMatch[1]);
                        if (!str_starts_with($jsUrl, 'http')) {
                            $jsUrl = 'https://auth.alipay.com' . (str_starts_with($jsUrl, '/') ? '' : '/') . $jsUrl;
                        }
                        $jsCh = curl_init($jsUrl);
                        curl_setopt_array($jsCh, [
                            CURLOPT_RETURNTRANSFER => true,
                            CURLOPT_HEADER         => false,
                            CURLOPT_FOLLOWLOCATION => true,
                            CURLOPT_MAXREDIRS      => 6,
                            CURLOPT_TIMEOUT        => 10,
                            CURLOPT_SSL_VERIFYPEER => false,
                            CURLOPT_SSL_VERIFYHOST => false,
                            CURLOPT_USERAGENT      => $ua,
                            CURLOPT_COOKIEJAR      => $cookieJar,
                            CURLOPT_COOKIEFILE     => $cookieJar,
                            CURLOPT_HTTPHEADER     => [
                                'Referer: https://auth.alipay.com/login/index.htm',
                            ],
                        ]);
                        curl_exec($jsCh);
                        curl_close($jsCh);
                    }

                    // 访问个人门户与全量明细页面，完成跨域换票并确保 ALIPAYJSESSIONID 与 zone 全部落盘
                    $probeUrls = [
                        'https://my.alipay.com/portal/i.htm',
                        'https://lab.alipay.com/consume/record/items.htm',
                        'https://consumeprod.alipay.com/record/advanced.htm',
                        'https://consumeprod.alipay.com/record/standard.htm',
                    ];
                    foreach ($probeUrls as $pUrl) {
                        $pCh = curl_init($pUrl);
                        curl_setopt_array($pCh, [
                            CURLOPT_RETURNTRANSFER => true,
                            CURLOPT_HEADER         => false,
                            CURLOPT_FOLLOWLOCATION => true,
                            CURLOPT_MAXREDIRS      => 5,
                            CURLOPT_TIMEOUT        => 8,
                            CURLOPT_SSL_VERIFYPEER => false,
                            CURLOPT_SSL_VERIFYHOST => false,
                            CURLOPT_USERAGENT      => $ua,
                            CURLOPT_COOKIEJAR      => $cookieJar,
                            CURLOPT_COOKIEFILE     => $cookieJar,
                            CURLOPT_HTTPHEADER     => [
                                'Referer: https://auth.alipay.com/',
                            ],
                        ]);
                        curl_exec($pCh);
                        curl_close($pCh);
                    }

                    // 解析 CookieJar 文件中的所有有效 Cookie
                    $cookieDict = [];
                    if (file_exists($cookieJar)) {
                        $lines = file($cookieJar, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
                        foreach ($lines as $line) {
                            $line = trim($line);
                            if (str_starts_with($line, '#HttpOnly_')) {
                                $line = substr($line, strlen('#HttpOnly_'));
                            } elseif (str_starts_with($line, '#') || $line === '') {
                                continue;
                            }
                            $cols = preg_split('/\t+/', $line);
                            if (count($cols) >= 7) {
                                $cName = trim($cols[5]);
                                $cVal = trim($cols[6]);
                                if ($cName !== '' && $cVal !== '' && $cVal !== 'deleted' && !in_array($cName, ['LoginForm', 'auth_goto_http_type'], true)) {
                                    $cookieDict[$cName] = $cVal;
                                }
                            }
                        }
                    }

                    $fullCookie = '';
                    foreach ($cookieDict as $k => $v) {
                        $fullCookie .= "{$k}={$v}; ";
                    }
                    $fullCookie = trim($fullCookie, '; ');
                    $base64Cookie = base64_encode($fullCookie);

                    $sessionData['cookie'] = $base64Cookie;
                    $sessionData['status'] = 'CONFIRMED';
                    @file_put_contents($sessionFile, json_encode($sessionData, JSON_UNESCAPED_UNICODE));

                    return [
                        'status'        => 'CONFIRMED',
                        'message'       => '🎉 支付宝扫码登录成功，已自动提取并编码保存商家 Cookie！',
                        'cookie'        => $base64Cookie,
                        'cookie_base64' => $base64Cookie,
                        'config_patch'  => ['cookie' => $base64Cookie, 'cookie_base64' => $base64Cookie],
                    ];
                }
            } catch (\Throwable) {}
        }

        return ['status' => 'WAITING', 'message' => '等待手机支付宝扫码确认...'];
    }

    public function getMeta(): array
    {
        return [
            'name'                                 => 'alipay_cookie_cloud',
            'title'                                => '支付宝扫码免挂 / Cookie 账单轮询插件',
            'pay_category'                         => 'alipay',
            'badge'                                => '👑 免费内置 / 扫码免挂',
            'supports_account_authorization'       => true,
            'authorization_label'                  => '扫码登录支付宝获取Cookie',
            'supports_account_capability_detection'=> false,
            'description'                          => '通过扫码登录获取支付宝网页版 Cookie（登录缓存）检测金额账单收款，并根据到账情况进行自动回调。',
            'inputs'                               => [
                [
                    'name'        => 'cookie',
                    'title'       => '支付宝 Cookie (base64)',
                    'placeholder' => '扫码登录自动获取；或手动粘贴 base64 编码的支付宝网页版 Cookie',
                    'type'        => 'textarea',
                    'required'    => true,
                ],
                [
                    'name'        => 'verify_name',
                    'title'       => '支付宝账号验证 (有时需要校验收款姓名的【姓】)',
                    'placeholder' => '例如: 张 (如遇支付宝安全校验时自动提交过白)',
                    'type'        => 'string',
                    'required'    => false,
                ],
                [
                    'name'        => 'qr_code_url',
                    'title'       => '收款码内容 (支持上传收款码图片自动解码)',
                    'placeholder' => '上传收款码自动解码，或手动填写二维码内容 (https://qr.alipay.com/...)',
                    'type'        => 'string',
                    'required'    => true,
                ],
                [
                    'name'        => 'query_interval',
                    'title'       => '云端轮询频率 (秒)',
                    'placeholder' => '推荐 3 秒',
                    'type'        => 'string',
                    'required'    => false,
                ],
            ],
        ];
    }

    public function upchannel(array $channelRow, array $config): array
    {
        $qrCodeUrl = trim((string)($config['qr_code_url'] ?? ''));
        if ($qrCodeUrl === '') {
            return ['code' => -1, 'msg' => '支付宝固定收款码不能为空'];
        }
        $cookie = trim((string)($config['cookie'] ?? ''));
        if ($cookie === '') {
            return ['code' => -1, 'msg' => '支付宝 Cookie 凭据不能为空'];
        }

        $config['qr_code_url'] = $qrCodeUrl;
        $config['cookie'] = $cookie;
        $config['verify_name'] = trim((string)($config['verify_name'] ?? ''));
        $config['query_interval'] = (int)($config['query_interval'] ?? 3);
        if ($config['query_interval'] < 1) {
            $config['query_interval'] = 3;
        }

        return ['code' => 1, 'data' => $config];
    }
}


