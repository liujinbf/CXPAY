<?php

declare(strict_types=1);

namespace app\service;

use app\model\Channel;
use app\payment\Contracts\MonitorableDriverInterface;
use app\payment\Contracts\ServerPollingDriverInterface;
use app\payment\PaymentManager;
use support\Authcode;
use app\service\AlertNotificationService;

/**
 * 自动化通道巡检与订单超时自动关闭服务 (后台 Worker 定时调度)
 */
class ChannelMonitorService
{
    private OrderService $orderService;
    private Authcode $authcode;
    private CallbillService $callbillService;

    public function __construct()
    {
        $this->orderService = new OrderService();
        $this->authcode = new Authcode();
        $this->callbillService = new CallbillService();
    }

    /**
     * 巡检过期未支付订单并自动关闭
     */
    public function checkExpiredOrders(): int
    {
        return $this->orderService->expirePendingOrders();
    }

    /**
     * 巡检已过期的商户套餐，自动将费率恢复为默认基础费率 2.0% (0.0200)
     */
    public function checkExpiredMerchantPlans(): int
    {
        $now = time();
        $expiredMerchants = \app\model\Merchant::where('plan_expire_time', '>', 0)
            ->where('plan_expire_time', '<=', $now)
            ->where('rate', '!=', '0.0200')
            ->get();

        $count = 0;
        foreach ($expiredMerchants as $merchant) {
            $merchant->rate = '0.0200';
            $merchant->save();
            $count++;
        }
        return $count;
    }

    /**
     * 检查通道心跳与在线状态并自动滚动清理超期未完成废弃订单
     */
    public function syncAll(): array
    {
        // 自动巡检关闭超时订单
        $this->checkExpiredOrders();
        // 自动清理 15 天前作废的未完成订单，防止数据库无限膨胀
        $this->orderService->autoPurgeArchivedOrders(15);
        
        return $this->checkChannelHeartbeats();
    }

    /**
     * 检查通道心跳与在线状态 (超时 60 秒无心跳自动切为离线休眠状态)
     */
    public function checkChannelHeartbeats(): array
    {
        // 只加载启用/停用通道（排除已物理删除或不相关记录），并限制字段减少内存占用。
        $channels = Channel::whereIn('status', [0, 1])
            ->select([
                'id', 'title', 'c_type', 'pay_category', 'status',
                'online_status', 'last_heartbeat_time', 'merchant_id',
                'online_since', 'offline_since', 'last_online_duration',
            ])
            ->get();
        $now = time();
        $timeoutThreshold = 180; // 放宽至 180 秒 (3分钟)，兼顾手机省电休眠与心跳网络抖动

        $onlineCount  = 0;
        $offlineCount = 0;
        $autoOfflined = 0;

        foreach ($channels as $channel) {
            $cType = (string)$channel->c_type;
            if (!PaymentManager::has($cType)) {
                if ((int)$channel->online_status !== 0) {
                    $channel->online_status = 0;
                    $channel->save();
                }
                $offlineCount++;
                continue;
            }

            $monitorMode = PaymentManager::monitorMode($cType);
            $requiresHeartbeat = $monitorMode === MonitorableDriverInterface::MODE_PUSH;
            if ($monitorMode === MonitorableDriverInterface::MODE_SERVER) {
                // 服务端轮询通道的在线状态由真实查询结果维护，不能在心跳巡检中无条件置为在线。
                (int)$channel->status === 1 && (int)$channel->online_status === 1
                    ? $onlineCount++
                    : $offlineCount++;
                continue;
            }
            if (!$requiresHeartbeat) {
                if ((int)$channel->status === 1) {
                    $needSave = false;
                    if ((int)$channel->online_status !== 1) {
                        $channel->online_status = 1;
                        $needSave = true;
                    }
                    if ((int)($channel->online_since ?? 0) <= 0) {
                        $channel->online_since = (int)($channel->create_time ?: time());
                        $needSave = true;
                    }
                    if ($needSave) {
                        $channel->save();
                    }
                    $onlineCount++;
                } else {
                    $offlineCount++;
                }
                continue;
            }

            $lastHeartbeat = (int)($channel->last_heartbeat_time ?? 0);

            if ((int)$channel->status === 1) {
                // 如果开启在线状态但长时间没有心跳，自动切断降级
                if ($lastHeartbeat <= 0 || ($now - $lastHeartbeat) > $timeoutThreshold) {
                    if ((int)$channel->online_status === 1) {
                        $onlineSince = (int)($channel->online_since ?? 0);
                        if ($onlineSince > 0) {
                            $channel->last_online_duration = max(0, $now - $onlineSince);
                        }
                        $channel->offline_since = $now;
                        $channel->online_status = 0;
                        $channel->save();
                    }
                    $offlineCount++;
                    $autoOfflined++;

                    // 派发通道掉线告警 (系统管理员 + 对应商户)
                    try {
                        $alertSvc = new AlertNotificationService();
                        $alertPayload = [
                            'channel_title' => $channel->title,
                            'c_type'        => $cType,
                        ];
                        $alertSvc->dispatchAdmin('channel_offline', $alertPayload);

                        if ($channel->merchant_id) {
                            $merchant = \app\model\Merchant::find($channel->merchant_id);
                            if ($merchant && !empty($merchant->pid)) {
                                $alertSvc->dispatchMerchant((string)$merchant->pid, 'channel_offline', $alertPayload);
                            }
                        }
                    } catch (\Throwable $e) {
                        error_log('[ChannelMonitorService] 掉线告警派发失败: ' . $e->getMessage());
                    }
                } else {
                    if ((int)$channel->online_status !== 1 || (int)($channel->online_since ?? 0) <= 0) {
                        $channel->online_status = 1;
                        $channel->online_since  = time();
                        $channel->save();
                    }
                    $onlineCount++;
                }
            } else {
                $offlineCount++;
            }
        }

        return [
            'total'        => count($channels),
            'online'       => $onlineCount,
            'offline'      => $offlineCount,
            'auto_offlined' => $autoOfflined,
        ];
    }

    /**
     * 轮询明确声明 MODE_SERVER 的通道。
     *
     * 每次重叠读取最近十分钟，依靠稳定账单号做幂等。这样进程短暂重启不会形成账单盲区，
     * 同时不需要把游标写回加密通道配置。
     */
    public function pollServerChannels(): array
    {
        $stats = ['channels' => 0, 'events' => 0, 'errors' => 0];
        $until = time();
        // 十分钟重叠窗口可覆盖短时网络故障或 Worker 重启；账单稳定流水号负责去重。
        $since = $until - 600;

        // 加载轮询所需字段；在线时长字段一并加载，避免 online_since 为 null 导致每轮轮询重置起始时间
        foreach (Channel::where('status', 1)
            ->select(['id', 'c_type', 'config', 'online_status', 'online_since', 'offline_since', 'last_online_duration', 'poll_fail_count'])
            ->get() as $channel) {
            $cType = (string)$channel->c_type;
            try {
                if (!PaymentManager::has($cType)
                    || PaymentManager::monitorMode($cType) !== MonitorableDriverInterface::MODE_SERVER) {
                    continue;
                }
                $driver = PaymentManager::make($cType);
                if (!$driver instanceof ServerPollingDriverInterface) {
                    throw new \RuntimeException('服务端监控驱动没有实现账单轮询契约');
                }

                $config = [];
                foreach (json_decode((string)$channel->config, true) ?: [] as $key => $value) {
                    $config[$key] = is_string($value) ? $this->authcode->decryptStored($value) : $value;
                }
                $config['__channel_id'] = (int)$channel->id;
                $events = array_slice($driver->pollPaymentEvents($config, $since, $until), 0, 100);
                $stats['channels']++;
                foreach ($events as $event) {
                    $billId = trim((string)($event['source_bill_id'] ?? ''));
                    $amount = trim((string)($event['amount'] ?? ''));
                    $occurredAt = (int)($event['occurred_at'] ?? 0);
                    if ($billId === '' || !preg_match('/^\d{1,8}(?:\.\d{1,2})?$/', $amount)
                        || (float)$amount <= 0 || $occurredAt <= 0) {
                        // 跳过单条格式非法账单，不影响同批次其他合法账单的处理
                        error_log("[ChannelMonitor] 跳过非法账单事件 cType={$cType}#{$channel->id}"
                            . " billId={$billId} amount={$amount} occurredAt={$occurredAt}");
                        continue;
                    }
                    $this->callbillService->processPush(
                        $cType,
                        'server-poller',
                        (float)$amount,
                        mb_substr((string)($event['remark'] ?? ''), 0, 255),
                        (int)$channel->id,
                        $billId,
                        $occurredAt,
                        (string)($event['raw_hash'] ?? ''),
                        'server-poller/1.0'
                    );
                    $stats['events']++;
                }
                // 轮询成功：清零失败计数，恢复在线状态
                $needSave = false;
                if ((int)($channel->poll_fail_count ?? 0) > 0) {
                    $channel->poll_fail_count = 0;
                    $needSave = true;
                }
                if ((int)$channel->online_status !== 1 || (int)($channel->online_since ?? 0) <= 0) {
                    $channel->online_status = 1;
                    $channel->online_since  = time();
                    $needSave = true;
                }
                if ($needSave) {
                    $channel->save();
                }
            } catch (\Throwable $e) {
                $stats['errors']++;
                $failCount = (int)($channel->poll_fail_count ?? 0) + 1;
                $channel->poll_fail_count = $failCount;

                // 容错机制：连续失败 3 次才将通道置为离线
                // 避免支付宝瞬时抖动（网络超时/服务端抖动）造成频繁掉线
                $maxFailsBeforeOffline = 3;
                if ($failCount >= $maxFailsBeforeOffline && (int)$channel->online_status !== 0) {
                    $now = time();
                    $onlineSince = (int)($channel->online_since ?? 0);
                    if ($onlineSince > 0) {
                        $channel->last_online_duration = max(0, $now - $onlineSince);
                    }
                    $channel->offline_since  = $now;
                    $channel->online_status  = 0;
                    $channel->save();
                    error_log("[ChannelMonitor] poll {$cType}#{$channel->id} 连续失败 {$failCount} 次，通道置为离线: " . $e->getMessage());
                } else {
                    // 未达到阈值，仅记录警告，保留在线状态
                    $channel->save(); // 保存 poll_fail_count
                    error_log("[ChannelMonitor] poll {$cType}#{$channel->id} 第 {$failCount} 次失败（容错中）: " . $e->getMessage());
                }
            }
        }

        return $stats;
    }

    /**
     * 跨日自动重置通道当日统计（today_money / today_count）
     *
     * T11 修复：原纯定时任务方案在 Worker 重启或宕机期间会漏跑，导致日限额跨日后永久失效，
     * 新方案改为按 stats_date 字段做增量判断：只对「上次重置日期 < 今日」的通道执行 UPDATE，
     * 既可作为定时任务主动调用，也可在心跳巡检等低频逻辑中伴随调用作为兜底自愈手段。
     *
     * stats_date 格式：YYYYMMDD 整数（如 20260731），由 patch_v6.sql 加字段。
     *
     * @return int 实际重置的通道数量（0 表示今日已重置，无需操作）
     */
    public function resetDailyStats(): int
    {
        $today = (int)date('Ymd');
        return Channel::query()
            ->where('stats_date', '<', $today)
            ->update([
                'today_money' => 0,
                'today_count' => 0,
                'stats_date'  => $today,
            ]);
    }
}
