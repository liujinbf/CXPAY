<?php

declare(strict_types=1);

namespace support;

/**
 * 易支付/平台统一签名工具类。
 */
class Sign
{
    /**
     * 生成易支付标准 MD5 签名
     */
    public static function makeSign(array $param, string $key): string
    {
        ksort($param);
        $signstr = '';

        foreach ($param as $k => $v) {
            if ($k !== 'sign' && $k !== 'sign_type' && $v !== '' && $v !== null) {
                $signstr .= $k . '=' . $v . '&';
            }
        }
        $signstr = rtrim($signstr, '&');
        $signstr .= $key;

        return md5($signstr);
    }

    /**
     * 校验 MD5 签名
     */
    public static function verifySign(array $data, string $key): bool
    {
        if (empty($data['sign'])) {
            return false;
        }
        $provided = strtolower(trim((string)$data['sign']));
        return preg_match('/^[a-f0-9]{32}$/', $provided) === 1
            && hash_equals(self::makeSign($data, $key), $provided);
    }

    /**
     * 构建发送给商户的异步/同步通知数据包 (金额严格保留 2 位小数 "1.00")
     *
     * 修复：原来 pid 字段错误传入 merchant_id（数字）
     *        正确应该是商户的字符串 PID（即 cx_merchant.您的 pid 字段）
     *
     * @param array  $order       订单数组
     * @param string $merchantPid 商户字符串 PID（如 '1000'）
     * @param string $merchantKey 商户 MD5 密鑰
     */
    public static function buildMerchantNotifyData(array $order, string $merchantPid, string $merchantKey): array
    {
        $data = [
            'pid'          => $merchantPid,          // 修复：使用字符串 PID 而非数字 merchant_id
            'trade_no'     => $order['trade_no'],
            'out_trade_no' => $order['out_trade_no'],
            'type'         => $order['pay_type'],
            'name'         => $order['subject'] ?? '网络充值',
            'money'        => number_format((float)$order['amount'], 2, '.', ''),
            'trade_status' => 'TRADE_SUCCESS',
        ];

        $data['sign']      = self::makeSign($data, $merchantKey);
        $data['sign_type'] = 'MD5';

        return $data;
    }

    /**
     * 校验商户接收回调的响应文本是否正确 (标准易支付规范要求商户返回 success)
     */
    public static function callbackNotify($response): bool
    {
        return is_string($response) && strtolower(trim($response)) === 'success';
    }
}
